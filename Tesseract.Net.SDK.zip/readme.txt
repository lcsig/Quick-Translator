Introduction
Tesseract.NET SDK it's a class library based on the tesseract-ocr project.

Bugs
Bugs should be reported through email at support@patagames.com